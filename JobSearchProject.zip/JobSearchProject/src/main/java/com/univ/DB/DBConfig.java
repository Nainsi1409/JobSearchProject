package com.univ.DB;

public interface DBConfig {
    String Driver="com.mysql.cj.jdbc.Driver";
    String URL="jdbc:mysql://localhost:3306/jobproject";
    String UNM="root";
    String PW="n@insi1409";
}
